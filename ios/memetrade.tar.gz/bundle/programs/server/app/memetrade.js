(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// memetrade.js                                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
  // counter starts at 0                                               //
  Session.setDefault('counter', 0);                                    // 3
  $(document).ready(function () {                                      // 4
    //all yiss graphs muthafucker                                      //
    /*var ctx = document.getElementById("rarePepes").getContext("2d");
    var myNewChart = new Chart(ctx).Line(pepe, {                       //
      scaleShowGridLines : true,                                       //
      scaleShowLabels : false,                                         //
      pointLabelFontFamily : "'Proxima-Nova'",                         //
      animationSteps : 100,                                            //
      scaleGridLineWidth : 0,                                          //
      datasetStrokeWidth : 4,                                          //
      scaleGridLineColor : "rgba(255,255,255,.1)",                     //
    });*/                                                              //
                                                                       //
    var dankCtx = document.getElementById("dankMemes").getContext("2d");
    dankChart = new Chart(dankCtx).Line(dank, {                        // 18
      //scaleShowGridLines : false,                                    //
      scaleShowLabels: false,                                          // 20
      pointLabelFontFamily: "'Avenir Next'",                           // 21
      animationSteps: 100,                                             // 22
      scaleGridLineWidth: 0,                                           // 23
      datasetStrokeWidth: 4,                                           // 24
      scaleGridLineColor: "rgba(255,255,255,.1)",                      // 25
      scaleLineColor: "rgba(255,255,255,.1)",                          // 26
      scaleFontFamily: "'Avenir Next', 'Helvetica', 'Arial', sans-serif",
      tooltipFontFamily: "'Avenir Next', 'Helvetica', 'Arial', sans-serif",
      scaleFontColor: "rgba(255, 255, 255, 0.5)",                      // 29
      scaleShowHorizontalLines: false                                  // 30
    });                                                                //
  });                                                                  //
                                                                       //
  Template.graph.helpers({                                             // 34
    stock_name: function () {                                          // 35
      return "Dank Memes";                                             // 36
    },                                                                 //
    stock_id: function () {                                            // 38
      return "dankMemes";                                              // 39
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.stock.events({                                              // 43
    "click .stock": function (event) {                                 // 44
      dankChart.destroy();                                             // 45
      document.getElementById("dankMemes").width = 355;                // 46
      document.getElementById("dankMemes").height = 200;               // 47
      var dankCtx = document.getElementById("dankMemes").getContext("2d");
      if (pepeOrDank == 1) {                                           // 49
        pepeOrDank = 0;                                                // 50
        chartData = pepe;                                              // 51
      } else {                                                         //
        pepeOrDank = 1;                                                // 53
        chartData = dank;                                              // 54
      }                                                                //
                                                                       //
      dankChart = new Chart(dankCtx).Line(chartData, {                 // 57
        //scaleShowGridLines : false,                                  //
        scaleShowLabels: false,                                        // 59
        pointLabelFontFamily: "'Avenir Next'",                         // 60
        animationSteps: 100,                                           // 61
        scaleGridLineWidth: 0,                                         // 62
        datasetStrokeWidth: 4,                                         // 63
        scaleGridLineColor: "rgba(255,255,255,.1)",                    // 64
        scaleLineColor: "rgba(255,255,255,.1)",                        // 65
        scaleFontFamily: "'Avenir Next', 'Helvetica', 'Arial', sans-serif",
        tooltipFontFamily: "'Avenir Next', 'Helvetica', 'Arial', sans-serif",
        scaleFontColor: "rgba(255, 255, 255, 0.5)",                    // 68
        scaleShowHorizontalLines: false                                // 69
      });                                                              //
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 78
  Meteor.startup(function () {                                         // 79
    // code to run on server at startup                                //
  });                                                                  //
}                                                                      //
                                                                       //
pepeOrDank = 0;                                                        // 84
                                                                       //
var pepe = {                                                           // 86
  labels: ["Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan"],           // 87
  datasets: [{                                                         // 88
    fillColor: "#689F38",                                              // 90
    strokeColor: "#ffffff",                                            // 91
    pointColor: "#ffffff",                                             // 92
    pointStrokeColor: "#fff",                                          // 93
    data: [62, 48, 41, 19, 29, 24, 21]                                 // 94
  }]                                                                   //
};                                                                     //
                                                                       //
var dank = {                                                           // 99
  labels: ["Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan"],           // 100
  datasets: [{                                                         // 101
    fillColor: "rgba(104, 159, 56, 0.5)",                              // 103
    strokeColor: "#ffffff",                                            // 104
    pointColor: "#ffffff",                                             // 105
    pointStrokeColor: "#fff",                                          // 106
    data: [41, 62, 64, 50, 53, 57, 90]                                 // 107
  }]                                                                   //
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=memetrade.js.map
